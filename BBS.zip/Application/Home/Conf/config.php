<?php
$conf = array(

);
return array_merge(include COMMON_PATH.'/Conf/config.php',$conf);