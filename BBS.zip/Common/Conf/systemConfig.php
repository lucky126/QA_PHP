<?php	return array (
  'SITE_INFO' => 
  array (
    'name' => '互动交流系统',
  ),
  'WEB_ROOT' => 'http://localhost:8081/BBS/',
  'AUTH_CODE' => 'JSptDn',
  'ADMIN_AUTH_KEY' => 'admin',
  'DB_HOST' => '127.0.0.1',
  'DB_NAME' => 'bbs',
  'DB_USER' => 'root',
  'DB_PWD' => '',
  'DB_PORT' => '3306',
  'DB_PREFIX' => 'bbs_',
  'webPath' => '/BBS/',
);?>